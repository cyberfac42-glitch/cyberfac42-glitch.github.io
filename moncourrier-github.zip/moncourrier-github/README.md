# 📝 MonCourrier

Service de génération de courriers administratifs par IA.

**Site** : https://cyberfac42-glitch.github.io/cyberfac42-glitch.github.io

## ⚙️ Configuration

Pour que le site fonctionne, tu dois ajouter ta clé API Anthropic comme "secret" GitHub :

1. Va dans **Settings** → **Secrets and variables** → **Actions**
2. Clique **"New repository secret"**
3. **Name** : `ANTHROPIC_API_KEY`
4. **Value** : ta clé API
5. **Add secret**

## 🚀 Déploiement

Le site se déploie automatiquement sur GitHub Pages quand tu pushes sur `main`.

**URL de ton site** : `https://cyberfac42-glitch.github.io`

## 📄 Fichiers

- `index.html` — Le site complet (HTML + CSS + JavaScript)
- `.gitignore` — Fichiers à ignorer

---

Made with ❤️ by Cyber Fac
